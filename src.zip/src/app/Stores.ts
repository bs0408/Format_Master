
export interface Stores
{
    gameid:number;
    gamename:String;
    gamePrice:number;

}