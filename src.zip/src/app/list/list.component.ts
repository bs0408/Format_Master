import { Component, OnInit } from '@angular/core';
import { StoringService } from '../storing.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  //styleUrls: ['./game.component.css']
})
export class ListComponent implements OnInit {

  constructor(private service : StoringService) { }

  ngOnInit() {
  }

  list=false;

  setUserDetails(data)
  {
    if(data.userName==""||data.userAddress==""||data.userAmount=="")
    {
      alert("Please fill the details")
    }
    else
    {
      alert("You can now start the playing!!!")
      this.service.setUserDetails(data);
      this.list=true;
    }
  }
}
