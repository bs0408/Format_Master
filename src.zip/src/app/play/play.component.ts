import { Component, OnInit } from '@angular/core';
import { StoringService } from '../storing.service';
import { Stores } from '../Stores';
@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {

  gamearr:Stores[];


  
  isUpdate  : boolean = false;
  gameid: number;
  gamename : string;
  gamePrice : number;
 

  constructor(private service : StoringService) { }

  ngOnInit() {
    this.service.getGameList().subscribe(data=>this.gamearr=data);
    
  }
  
played(game)
{
  this.service.played(game);
  
}
delete(game1: Stores) {
  
   let arr=this.gamearr.filter(p=>p.gameid!=game1.gameid);
   this.gamearr=arr;

}
}